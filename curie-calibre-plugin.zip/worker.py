import json
import os
import re
import threading
import time
import traceback

from qt.core import QThread, pyqtSignal

from calibre_plugins.curie.api_client import (
    generate_book_data, enrich_with_claude, calc_cost, wait_for_rate_limit,
)
from calibre_plugins.curie.epub_utils import extract_spine_texts, build_epub_chunks

MIN_OCCURRENCES = 3

_Cancelled = type('_Cancelled', (Exception,), {})


class CurieWorker(QThread):
    progress     = pyqtSignal(str)
    step1_done   = pyqtSignal(dict, dict)                    # book_data, usage1
    analysis_done = pyqtSignal(dict, dict, dict, str, dict)  # book_data, usage1, usage2, output_path, inject_stats
    error        = pyqtSignal(str)

    def __init__(self, api_key, title, author, epub_path, include_characters,
                 include_places, language, model, output_path, inject_only=False,
                 target_reader='koreader', hint_density='every_10_paragraphs'):
        super().__init__()
        self.api_key            = api_key
        self.title              = title
        self.author             = author
        self.epub_path          = epub_path
        self.include_characters = include_characters
        self.include_places     = include_places
        self.language           = language
        self.model              = model
        self.output_path        = output_path
        self.inject_only        = inject_only
        self.target_reader      = target_reader
        self.hint_density       = hint_density
        self._stop              = threading.Event()

    def cancel(self):
        self._stop.set()

    def _progress(self, msg):
        if self._stop.is_set():
            raise _Cancelled()
        self.progress.emit(msg)

    def run(self):
        try:
            if self.inject_only:
                self._progress('Loading existing analysis…')
                with open(self.output_path, 'r', encoding='utf-8') as f:
                    book_data = json.load(f)
                self._progress('Injecting footnote hints into EPUB…')
                from calibre_plugins.curie.epub_injector import inject_footnotes
                inject_stats = inject_footnotes(self.epub_path, book_data, self.target_reader, self.hint_density)
                self.analysis_done.emit(dict(book_data), {}, {}, self.output_path, inject_stats or {})
                return

            # ── Step 1 ────────────────────────────────────────────────────────
            book_data, usage1, rate_headers = generate_book_data(
                self.api_key, self.title, self.author,
                self.include_characters, self.include_places,
                self.language, self.model,
                progress_cb=self._progress,
            )
            self.step1_done.emit(dict(book_data), dict(usage1))

            # ── Step 2a: programmatic counting ────────────────────────────────
            self._progress('Step 2 (EPUB spoiler analysis): Parsing EPUB…')
            chapters = extract_spine_texts(self.epub_path)

            self._progress('Step 2 (EPUB spoiler analysis): Counting occurrences…')
            _add_chapter_and_occurrences(book_data, chapters)

            # ── Proactive rate-limit pause before Step 2 Claude calls ─────────
            epub_total_chars = sum(len(text) for _, text in chapters)
            tokens_needed    = epub_total_chars // 4 + 5_000
            wait_for_rate_limit(rate_headers, tokens_needed=tokens_needed,
                                progress_cb=self._progress)

            # ── Step 2b: Claude enrichment (chunked for large books) ──────────
            epub_chunks  = build_epub_chunks(chapters)
            n_chunks     = len(epub_chunks)
            usage2       = {'input_tokens': 0, 'output_tokens': 0,
                            'cache_write_tokens': 0, 'cache_read_tokens': 0}
            current_data = book_data

            for i, chunk_text in enumerate(epub_chunks):
                chunk_label = f'part {i + 1}/{n_chunks}' if n_chunks > 1 else ''
                current_data, chunk_usage = enrich_with_claude(
                    self.api_key, current_data, chunk_text, self.model,
                    progress_cb=self._progress,
                    chunk_label=chunk_label,
                )
                for k in usage2:
                    usage2[k] += chunk_usage.get(k, 0)

            book_data_enriched = current_data

            # ── Step 2c: post-processing ──────────────────────────────────────
            _fix_schema(book_data_enriched)
            _filter_aliases(book_data_enriched)
            _add_chapter_and_occurrences(book_data_enriched, chapters, only_missing=True)
            _filter_by_occurrences(book_data_enriched)

            # ── Save sidecar JSON ─────────────────────────────────────────────
            self._progress('Saving output…')
            os.makedirs(os.path.dirname(self.output_path), exist_ok=True)
            with open(self.output_path, 'w', encoding='utf-8') as f:
                json.dump(book_data_enriched, f, indent=2, ensure_ascii=False)

            # ── Step 3: Inject footnotes into EPUB ────────────────────────────
            self._progress('Step 3: Injecting footnote hints into EPUB…')
            from calibre_plugins.curie.epub_injector import inject_footnotes
            inject_stats = inject_footnotes(self.epub_path, book_data_enriched, self.target_reader, self.hint_density)

            self.analysis_done.emit(
                dict(book_data_enriched),
                dict(usage1),
                dict(usage2 or {}),
                self.output_path,
                inject_stats or {},
            )

        except _Cancelled:
            pass  # clean exit — QThread.finished fires naturally

        except Exception as exc:
            self.error.emit(f'{exc}\n\n{traceback.format_exc()}')


# ── Post-processing helpers ───────────────────────────────────────────────────

def _scan(names, chapters):
    first_chapter = None
    total = 0
    for chapter_num, text in chapters:
        count = sum(
            len(re.findall(r'\b' + re.escape(n) + r'\b', text, re.IGNORECASE))
            for n in names if n
        )
        total += count
        if count > 0 and first_chapter is None:
            first_chapter = chapter_num
    return first_chapter, total


def _add_chapter_and_occurrences(book_data, chapters, only_missing=False):
    for char in book_data.get('characters', []):
        if only_missing and char.get('chapter') is not None:
            continue
        primary = char.get('full_name') or char.get('name', '')
        if not primary:
            continue
        names = [primary] + char.get('nicknames', [])
        char['chapter'], char['occurrences'] = _scan(names, chapters)

    for loc in book_data.get('locations', []):
        if only_missing and loc.get('chapter') is not None:
            continue
        primary = loc.get('name') or loc.get('full_name', '')
        if not primary:
            continue
        loc['chapter'], loc['occurrences'] = _scan([primary], chapters)


def _fix_schema(book_data):
    """Drop entries where Claude returned the wrong field names; remove spurious top-level fields."""
    book_data.pop('note', None)
    book_data['characters'] = [
        c for c in book_data.get('characters', [])
        if c.get('full_name') or c.get('name')
    ]
    book_data['locations'] = [
        loc for loc in book_data.get('locations', [])
        if loc.get('name') or loc.get('full_name')
    ]


def _filter_aliases(book_data):
    for char in book_data.get('characters', []):
        char['nicknames'] = [n for n in char.get('nicknames', []) if n and n[0].isupper()]
    for loc in book_data.get('locations', []):
        primary_words = set((loc.get('name') or loc.get('full_name', '')).lower().split())
        loc['aliases'] = [
            a for a in loc.get('aliases', [])
            if a and a[0].isupper()
            and len(a.split()) >= 2                                    # single words are too broad
            and not set(a.lower().split()).issubset(primary_words)     # must add at least one new word
        ]


def _filter_by_occurrences(book_data, min_occurrences=MIN_OCCURRENCES):
    for key in ('characters', 'locations'):
        book_data[key] = [
            e for e in book_data.get(key, [])
            if (e.get('occurrences') or 0) >= min_occurrences
        ]
